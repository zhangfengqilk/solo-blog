title: Invalid bound statement (not found) 解决办法
date: '2019-09-13 17:56:17'
updated: '2019-09-13 17:56:55'
tags: [待分类]
permalink: /articles/2019/09/13/1568368577755.html
---
![](https://img.hacpai.com/bing/20180110.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

> Invalid bound statement (not found)

在使用mybatis plus时，先出现了下面这个错误

> java.lang.Class org.mybatis.spring.annotation.MapperScan.factoryBean()

于是我就随手百度了一个解决方案
```
<dependency>  
    <groupId>org.mybatis.spring.boot</groupId>  
    <artifactId>mybatis-spring-boot-starter</artifactId>  
    <version>1.1.1</version>  
</dependency>
```
问题得到了解决，不报错了，但接下来就是噩梦的开始，在调用数据库查询时出现
> Invalid bound statement (not found) 

的错误，百度了一圈也没有一个能解决。都是在说配置mapper路径扫描，和xml静态资源路径。

我在xml中自己写了一个sql语句，竟然可以查询到数据，但基于mybatis plus的baseMapper中的接口都在报这个错误。那么问题定位到BaseMapper没有正确的注入。

通过对比网上正常的示例代码，一行行比较pom.xml文件中的依赖，终于发现了一个问题

上面引用的mybatis-spring-boot-starter引用的不对，应该引用下面这个包。

```
<dependency>
     <groupId>com.baomidou</groupId>
     <artifactId>mybatis-plus-boot-starter</artifactId>
      <version>3.2.0</version>
</dependency>
```
替换就解决了
