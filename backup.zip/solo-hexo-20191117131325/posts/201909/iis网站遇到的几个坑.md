title: iis网站遇到的几个坑
date: '2019-09-04 12:35:53'
updated: '2019-09-04 12:36:56'
tags: [待分类]
permalink: /articles/2019/09/04/1567571753109.html
---
![](https://img.hacpai.com/bing/20181003.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

1 打开首页后点登录按钮，弹出登录失败

查看错误原因，是由于虽然在IIS里选了Framework4.0的驱动，但系统没有安装成功，需要手动安装一次，Windows7安装SQL server 2008 R2之后，将网站发布到IIS，访问发生如下错误：

HTTP 错误 500.21 - Internal Server Error处理程序“NickLeeCallbackHandler”在其模块列表中有一个错误模块“ManagedPipelineHandler”

原因：在安装Framework v4.0之后，再启用IIS，导致Framework没有完全安装

解决：开始->所有程序->附件->鼠标右键点击“命令提示符”->以管理员身份运行->%windir%\Microsoft.NET\Framework\v4.0.30319\aspnet_regiis.exe -i

注：需要更改.net版本为v4.0.30319

![](https://images2015.cnblogs.com/blog/851401/201608/851401-20160819105210984-1034013654.png)

设置应用程序池默认.NET版本为v4.0![1.png](https://img.hacpai.com/file/2019/09/1-87abdb64.png)
 ![2.jpg](https://img.hacpai.com/file/2019/09/2-9c0b57c1.jpg)

2 上面的错误解决了以后，再次打开首页，出现首页打不开的情况。

IIS部署的网站打开出现问题：

CS0016: 未能写入输出文件“c:\Windows\Microsoft.NET\Framework64\v4.0.30319\Temporary ASP.NET Files\root\6ba3b83b\52fcdeee\App_global.asax.7ky3gsdp.dll”--“拒绝访问。 ”
![3.png](https://img.hacpai.com/file/2019/09/3-4875ac55.png)

将windows/temp属性-安全-高级  添加IIS_USERS用户，同时编辑权限为完全控制(写入和编辑)保存即可

 

3 修改完成后，登录弹出登录密码错误

这说明系统配置已经没有问题，应该就是数据库没有对应的用户名和密码，可以用以前提供的数据库导入用户名和密码

4 用360 的急速模式可以登录，但兼容模式下无法显示组件
![4.png](https://img.hacpai.com/file/2019/09/4-efdfc597.png)


5 360浏览器的急速模式下，不显示视频组件，需要安装海康的驱动

6 360浏览器的急速模式下，切换页面，视频组件不消失，会叠加显示。
![6.png](https://img.hacpai.com/file/2019/09/6-6255faef.png)

