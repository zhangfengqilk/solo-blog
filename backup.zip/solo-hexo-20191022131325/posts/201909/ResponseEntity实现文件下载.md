title: ResponseEntity实现文件下载
date: '2019-09-12 13:25:40'
updated: '2019-09-12 13:27:28'
tags: [待分类]
permalink: /articles/2019/09/12/1568265940499.html
---
* **需求:**

> 点击页面上的超链接,然后下载服务器端的文件:

* **实现：**

ResponseEntity
需要传入3个参数,分别是:请求体、请求头和状态码
具体的代码如下:

 @RequestMapping("/testResponseEntity")
    public ResponseEntity<byte[]> testResponseEntity(HttpSession session) throws IOException {
        byte[] body=null;
        ServletContext sc=session.getServletContext();
        InputStream in=sc.getResourceAsStream("/files/11.txt");
        body=new byte[in.available()];
        in.read(body);
 
        HttpHeaders headers=new HttpHeaders();
        headers.add("Content-Disposition","attachment;filename=11.txt");
 
        HttpStatus statusCode=HttpStatus.OK;
 
        ResponseEntity<byte[]> response=new ResponseEntity<byte[]>(body,headers,statusCode);
        return response;
    }

前端页面代码

	<a href="/testResponseEntity">testResponseEntity</a>
