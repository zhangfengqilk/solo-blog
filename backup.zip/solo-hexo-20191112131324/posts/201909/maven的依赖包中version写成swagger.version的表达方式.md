title: maven的依赖包中version写成swagger.version的表达方式
date: '2019-09-05 08:31:56'
updated: '2019-09-05 08:31:56'
tags: [待分类]
permalink: /articles/2019/09/05/1567643516784.html
---
如下所示，在pom.xml中依赖包的version写为${swagger.version}，那么这个表达式表示什么意思呢？
```
		<!-- swagger2  restful api 文档  start -->
		<dependency>
			<groupId>io.springfox</groupId>
			<artifactId>springfox-swagger2</artifactId>
			<version>${swagger.version}</version>
		</dependency>
		<dependency>
			<groupId>io.springfox</groupId>
			<artifactId>springfox-swagger-ui</artifactId>
			<version>${swagger.version}</version>
		</dependency>
		<!-- swagger2  restful api 文档  end -->
```
这个是pom文件中的一种属性定义，在上面定义属性：
```
	<properties>
		<java.version>1.8</java.version>
		<mybatis.verson>1.3.2</mybatis.verson>
		<mybatis.pagehelper.verson>1.2.7</mybatis.pagehelper.verson>
		<druid.version>1.1.10</druid.version>
		<log4j.version>1.2.17</log4j.version>
		<mapstruct.version>1.2.0.Final</mapstruct.version>
		<swagger.version>2.8.0</swagger.version>
	</properties>
```
将每个包的引用定义在properties中，下面引用的话就直接写${swagger.version}，需要修改version直接统一修改上面的版本即可。
