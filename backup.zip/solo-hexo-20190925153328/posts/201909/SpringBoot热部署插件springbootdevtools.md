title: SpringBoot：热部署插件spring-boot-devtools
date: '2019-09-19 16:23:08'
updated: '2019-09-19 16:23:08'
tags: [待分类]
permalink: /articles/2019/09/19/1568881388680.html
---
![](https://img.hacpai.com/bing/20190819.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

### 一、热部署插件spring-boot-devtools的介绍   
spring-boot-devtools 是一个为开发者服务的一个模块，其中最重要的功能就是自其深层原理是使用了两个ClassLoader，一个Classloader加动应用代码更改到最新的App上面去。原理是在发现代码有更改之后，重新启动应用，但是速度比手动停止后再启动还要更快，更快指的不是节省出来的手工操作的时间。   
其深层原理是使用了两个ClassLoader，一个Classloader加载那些不会改变的类（第三方Jar包），另一个ClassLoader加载会更改的类，称为 restart ClassLoader   
这样在有代码更改的时候，原来的restart ClassLoader 被丢弃，重新创建一个restart ClassLoader，由于需要加载的类相比较少，所以实现了较快的重启时间（5秒以内）   
### 二、热部署插件spring-boot-devtools   
1、在pom.xml配置文件添加依赖包   
```   
<!-- spring-boot-devtools依赖包 -->   
<dependency>   
 <groupId>org.springframework.boot</groupId>   
 <artifactId>spring-boot-devtools</artifactId>   
 <optional>true</optional>   
 <scope>true</scope>   
</dependency>   
```   
2、在pom.xml配置文件添加spring-boot-devtools插件   
```   
<!-- 这是spring boot devtool plugin -->   
<plugin>   
 <groupId>org.springframework.boot</groupId>   
 <artifactId>spring-boot-maven-plugin</artifactId>   
 <configuration>   
 <!--fork :  如果没有该项配置，肯呢个devtools不会起作用，即应用不会restart -->   
 fork>true</fork>   
 </configuration>   
</plugin>   
```
