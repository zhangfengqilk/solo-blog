title: Druid数据源的使用
date: '2019-09-04 16:10:02'
updated: '2019-09-04 16:10:20'
tags: [待分类]
permalink: /articles/2019/09/04/1567584601964.html
---
![](https://img.hacpai.com/bing/20180628.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

### 1 Druid数据源简介

　　Druid是Java语言中最好的数据库连接池。Druid能够提供强大的监控和扩展功能。通过访问http://localhost:8080(自己的端口)/druid/ 可以查看监控面板

### 2 在application.yml文件中添加配置

```
#访问端口
server:
  port: 8082
spring:
  application:
    name: bms
  datasource:
          #JDBC配置
          name: test
          url: jdbc:mysql://127.0.0.1:3306/bms?autoReconnect=true&useUnicode=true&characterEncoding=utf-8&allowMultiQueries=true
          username: root
          password: root
          driver-class-name: com.mysql.jdbc.Driver

          # 使用druid数据源
          type: com.alibaba.druid.pool.DruidDataSource

          #--------------------Druid 连接池配置 start-----------------------------
          druid:
            #初始化大小，最小，最大
            initial-size: 5
            min-idle: 1
            max-active: 50
            #配置获取连接等待超时时间
            max-wait: 60000
            # 配置间隔多久才进行一次检测，检测需要关闭的空闲连接，单位是毫秒
            time-between-eviction-runs-millis: 60000
            # 配置一个连接在池中最小生存的时间，单位是毫秒
            min-evictable-idle-time-millis: 300000
            validation-query: SELECT 1 FROM DUAL
            test-while-idle: true
            test-on-borrow: false
            test-on-return: false
            # 打开PSCache，并且指定每个连接上PSCache的大小
            pool-prepared-statements: false
            max-pool-prepared-statement-per-connection-size: 20

            #--------------------监控配置 start-----------------------------
            # 配置监控统计拦截的filters，去掉后监控界面sql无法统计，'wall'用于防火墙
            filters: stat,wall,log4j
            # 通过connectProperties属性来打开mergeSql功能；慢SQL记录
            connection-properties: druid.stat.mergeSql=true
            filter:
              stat:
                slow-sql-millis: 5000

          #--------------------Druid 连接池配置 end-----------------------------
```
###  3 Pom中新增依赖~~~~ 

```
		<!-- Druid连接池 -->
		<dependency>
			<groupId>com.alibaba</groupId>
			<artifactId>druid-spring-boot-starter</artifactId>
			<version>${druid.version}</version>
		</dependency>
```
