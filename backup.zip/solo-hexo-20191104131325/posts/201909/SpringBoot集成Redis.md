title: SpringBoot集成Redis
date: '2019-09-19 19:41:32'
updated: '2019-09-19 19:41:32'
tags: [待分类]
permalink: /articles/2019/09/19/1568893291984.html
---
![](https://img.hacpai.com/bing/20190506.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

### 1 在pom.xml中引入依赖
```
 <!-- spring boot redis 缓存引入 -->
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-data-redis</artifactId>
            <version>2.0.4.RELEASE</version>
        </dependency>
```

### 2 在SpringBoot核心配置文件中配置redis连接信息
```
# Redis服务器地址
spring.redis.host=127.0.0.1
# Redis服务器连接端口
spring.redis.port=6379
# Redis服务器连接密码 没有密码就不填,默认为空
spring.redis.password=123456
```

### 3  配置了上面两步骤,SpringBoot将自动配置RedisTemplate，在需要操作redis的类中注入RedisTemplate,只能支持下面两种类型的RedisTemplate

```
    @Autowired
    private RedisTemplate<Object,Object> redisTemplate;

    @Autowired
    private RedisTemplate<String,String> redisTemplate;

```

