title: SOLO博客如何部署在服务器
date: '2019-08-25 20:08:53'
updated: '2019-08-25 20:08:53'
tags: [待分类]
permalink: /articles/2019/08/25/1566734933415.html
---
把 solo 修改皮肤后打包成 war，部署到 tomcat 上。修改了端口为 80，latke.properties 也改好了 serverport。本地 tomcat 运行正常，war 包放到服务器 tomcat 可以运行出来。但加载的主页是默认主题。
 738 x 554      919 x 690
想登录修改主题，登录不了，一直显示密码错误。注册显示无法注册。没法进入后台管理 QAQ 这是什么情况，还需要配置什么部分吗？

作者：mogiihu
链接：https://hacpai.com/article/1531899987500
来源：黑客派
协议：CC BY-SA 4.0 https://creativecommons.org/licenses/by-sa/4.0/
