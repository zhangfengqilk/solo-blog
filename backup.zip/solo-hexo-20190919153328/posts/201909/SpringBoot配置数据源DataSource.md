title: ' SpringBoot配置数据源DataSource'
date: '2019-09-05 10:39:07'
updated: '2019-09-05 10:39:38'
tags: [待分类]
permalink: /articles/2019/09/05/1567651147581.html
---
## 1  使用properties文件配置springboot默认数据源
这种方式十分简单，只用在application.properties文件中配置数据库连接属性即可。

```
spring.datasource.url=jdbc:mysql://localhost:3306/test?characterEncoding=utf8&characterSetResults=utf8&autoReconnect=true&failOverReadOnly=false
spring.datasource.username=root
spring.datasource.password=root
```
   运行测试方法,查看springboot是否自动配置数据源

```
@RunWith(SpringRunner.class)
@SpringBootTest
public class MonsterlanApplicationTests {
   @Autowired
   DataSourceProperties dataSourceProperties;

   @Autowired
   ApplicationContext applicationContext;

   @Test
   public void contextLoads() {
      // 获取配置的数据源
      DataSource dataSource = applicationContext.getBean(DataSource.class);
      // 查看配置数据源信息
      System.out.println(dataSource);
      System.out.println(dataSource.getClass().getName());
      System.out.println(dataSourceProperties);
      //执行SQL,输出查到的数据
      JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
      List<?> resultList = jdbcTemplate.queryForList("select * from test");
      System.out.println("===>>>>>>>>>>>" + JSON.toJSONString(resultList));
   }
}
```
通过输出信息，我们可以看到我们通过properties文件配置数据源十分方便，springboot会直接在容器中构建一个dataSource供我们使用。



## 2  通过注解配置数据源DataSource

通过注解配置datasource，这个比使用springboot默认的数据源配置要更灵活一些，还可以根据项目需求配置多个不同的DataSource(如果项目使用到多个数据库)

在myDataSource.properties文件中配置数据库属性

```
spring.datasource.other.jdbc-url=jdbc:mysql://localhost:3306/test?characterEncoding=utf8&characterSetResults=utf8&autoReconnect=true&failOverReadOnly=false
spring.datasource.other.username=root
spring.datasource.other.password=root
spring.datasource.other.driver-class-name=com.mysql.jdbc.Driver
```
这里有个注意事项:

    springboot 2.0+中使用jdbc-url配置数据库URL, 1.5中使用url,不然会导致一个错误。jdbcUrl is required with driverClassName

创建一个配置类DataSourceConfig
```
@Configuration
public class DataSourceConfig {

    @Bean(name = "myDataSource")
    @Qualifier("myDataSource")
    @ConfigurationProperties(prefix="spring.datasource.other")
    public DataSource getMyDataSource(){
        return DataSourceBuilder.create().build();
    }
    
}
```
通过Junit测试数据源

```
@RunWith(SpringRunner.class)
@SpringBootTest
public class MonsterlanApplicationTests {
   @Autowired
   DataSourceProperties dataSourceProperties;

   @Autowired
   ApplicationContext applicationContext;

   @Resource(name = "myDataSource")
   private DataSource myDataSource;

   @Test
   public void contextLoads() {
      //执行SQL,输出查到的数据
      JdbcTemplate jdbcTemplate = new JdbcTemplate(myDataSource);
      List<?> resultList = jdbcTemplate.queryForList("select * from menu");
      System.out.println("===>>>>>>>>>>>" + JSON.toJSONString(resultList));
   }
}
```
这样我们就能使用数据源进行数据库操作了。


相关maven依赖配置:

```
<dependency>
   <groupId>org.springframework.boot</groupId>
   <artifactId>spring-boot-starter-data-jpa</artifactId>
</dependency>
<!-- Mysql驱动包 -->
<dependency>
   <groupId>mysql</groupId>
   <artifactId>mysql-connector-java</artifactId>
</dependency>
<!-- alibaba JSON工具 -->
<dependency>
   <groupId>com.alibaba</groupId>
   <artifactId>fastjson</artifactId>
   <version>1.2.4</version>
</dependency>
```


