title: java测试时加上@RunWith
date: '2019-09-13 18:07:49'
updated: '2019-09-13 18:07:49'
tags: [待分类]
permalink: /articles/2019/09/13/1568369269088.html
---

测试数据库查询时必须使用上下文，所以测试类应该要加上下面这两个注解。
```
@RunWith(SpringRunner.class)
@SpringBootTest
```

否则报错：
> com.example.testmp.entity.User Not Found TableInfoCache.
