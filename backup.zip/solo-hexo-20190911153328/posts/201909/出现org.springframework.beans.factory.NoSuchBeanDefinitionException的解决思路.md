title: 出现org.springframework.beans.factory.NoSuchBeanDefinitionException 的解决思路
date: '2019-09-11 15:13:22'
updated: '2019-09-11 15:13:22'
tags: [待分类]
permalink: /articles/2019/09/11/1568186002514.html
---

> Caused by: org.springframework.beans.factory.BeanCreationException: Could not autowire field: private cn.itcast.crm.service.BaseDictService 
cn.itcast.crm.controller.CustomerController.baseDictService; nested exception is org.springframework.beans.factory.NoSuchBeanDefinitionException: No qualifying bean of type [cn.itcast.crm.service.BaseDictService] found for dependency: expected at least 1 bean which qualifies as autowire candidate for this dependency. Dependency annotations: {@org.springframework.beans.factory.annotation.Autowired(required=true)}
严重: StandardWrapper.Throwable
org.springframework.beans.factory.BeanCreationException: Error creating bean with name 'customerController': Injection of autowired dependencies failed; nested exception is org.springframework.beans.factory.BeanCreationException: Could not autowire field: private cn.itcast.crm.service.BaseDictService cn.itcast.crm.controller.CustomerController.baseDictService; nested exception is org.springframework.beans.factory.NoSuchBeanDefinitionException: No qualifying bean of type [cn.itcast.crm.service.BaseDictService] found for dependency: expected at least 1 bean which qualifies as autowire candidate for this dependency. Dependency annotations: {@org.springframework.beans.factory.annotation.Autowired(required=true)}

**如果您使用注释并且实现注释正确，请检查扫描实现所在的包**

```
@MapperScan("com.polargarden.mp.mapper")
```

